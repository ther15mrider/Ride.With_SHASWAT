# THE R15M RIDER website — No Booking Version

A responsive static website for motorcycle touring inspiration, with Odisha, Ladakh and Nepal route ideas, gallery placeholders, YouTube/Instagram links, and a Google Maps search link.

**Booking features have been removed.** There is no booking form, reservation workflow, or booking/enquiry button. Visitors can follow the channel or message the Instagram account directly.

## Preview locally
Open `index.html` in a browser. An internet connection is needed for the remote scenic photos.

## Before publishing
1. Replace the gallery placeholders with your own ride photos/videos if desired.
2. Review all routes, trip durations, permits, and any prices before advertising.
3. Test on mobile and desktop.

## Publish free with GitHub Pages
1. Sign in to GitHub and create a new public repository, e.g. `the-r15m-rider`.
2. Upload `index.html`, `style.css`, `script.js`, and the `assets` folder. `README.md` is optional.
3. In the repository, open **Settings → Pages**. Under build/deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
4. Wait for GitHub Pages to provide the published URL. Open it on your phone and test the links.

The image in `assets/design-preview.png` is a visual reference, not the functioning webpage itself. This is a front-end website and does not include a server, database, online payments, or customer-review verification.
